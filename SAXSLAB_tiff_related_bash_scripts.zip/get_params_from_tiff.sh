#!/bin/bash
#
# get_params_from_tiff <file> <entry 1> ... <entry N>
# get_params_from_tiff <file>

if [ "$#" -lt 1 ]; then
	echo "Specify list of parameters:"
	echo "     get_params_from_tiff <file> <entry 1> ... <entry N>"
	echo "e.g. get_params_from_tiff im_0049492_caz.tiff vp1 vg1 zkstage"
	echo "List all available parameters:"
	echo "     get_params_from_tiff <file>"
	echo "e.g. get_params_from_tiff im_0049492_caz.tiff"
	exit
fi

file=$1
if [ ! -f $file ]; then
	echo "File $file does not exist."
	exit
fi

if [ "$#" -ge 2 ]; then
	for ((i=2; i<=$#; i++)); do
		entry=${!i}
		# ''
		# echo "Arg #$i='${!i}'"
		printf "$entry = "
		sed -n '/PILATUS/p' $file | sed -n "s/^.*$entry\">//p" | cut -d "<" -f1
	done
else
	# print specific line, create newline after each </param>, kill for each line all text until incl <param name=" pattern, replace "> with " = "
	sed -n '/PILATUS/p' $file | sed 's/<\/param>/\n/g' | sed -n 's/^.*<param name="//p' | sed 's/">/ = /g'
fi
