#!/bin/bash
#

if [ "$#" -lt 1 ]; then
	echo "Print list of parameters for a list of files (allows wildcards and patterns):"
	echo "     get_params_from_tiff <list of files> -p <list of params>"
	echo "e.g. get_params_from_tiff im_0049492_caz.tiff im_0049495_caz.tiff -p vp1 vg1 zkstage"
	echo "e.g. get_params_from_tiff im_00494{8[2-4],9[0-3]}_caz.tiff -p vp1 vg1 zkstage"
	echo ""
	echo "List all available parameters for one file:"
	echo "     get_params_from_tiff <file>"
	echo "e.g. get_params_from_tiff im_0049492_caz.tiff"
	exit
fi



# min -g 3 2 5 1
# max -g 1.5 5.2 2.5 1.2 5.7
# min -h 25M 13G 99K 1098M
# max -d "Lorem" "ipsum" "dolor" "sit" "amet"
# min -M "OCT" "APR" "SEP" "FEB" "JUL"
min() {
	printf "%s\n" "${@:2}" | sort "$1" | head -n1
}
max() {
	# using sort's -r (reverse) option - using tail instead of head is also possible
	min ${1}r ${@:2}
}



# check and assign input
filelist=()
paramlist=()
file_instead_of_param=true
for ((i=1; i<=$#; i++)); do

	# check for -p flag
	if [ "${!i}" == "-p" ]; then
		file_instead_of_param=false
		continue
	fi

	# read input args either into filelist or paramlist
	if $file_instead_of_param ; then
		if [ ! -f ${!i} ]; then
			echo "File ${!i} does not exist."
			exit
		fi
		filelist=(${filelist[@]} ${!i})
	else
		paramlist=(${paramlist[@]} ${!i})
	fi
done

#echo ${filelist[@]}
#echo ${paramlist[@]}
#echo ""

# print output
if [ "$#" -ge 2 ]; then
	# create matrix of filenames and parameters

	min_char_per_col=12
	col_del="  "

	# find longest file name in 1st col
	longest=0
	for file in ${filelist[@]}
	do
		if [ ${#file} -gt $longest ]; then
			longest=${#file}
		fi
	done

	#echo $longest

	col_width="$(max -g $min_char_per_col $longest)"
	char_per_col_list=($col_width)
	printf "%-${char_per_col_list[0]}s" "FILE"

	# find lengths of param cols
	for param in ${paramlist[@]}
	do
		col_width="$(max -g $min_char_per_col ${#param})"
		char_per_col_list=(${char_per_col_list[@]} $col_width)
		printf '%s' "$col_del"
		printf "%-${col_width}s" "$param"
	done
	printf '\n'

	#echo ${char_per_col_list[@]}

	# print file-param matrix
	for file in ${filelist[@]}
	do
		col_index=0

		printf "%-${char_per_col_list[$col_index]}s" "$file"

		for param in ${paramlist[@]}
		do
			col_index=$((col_index+1))

			val=`sed -n '/PILATUS/p' $file | sed -n "s/^.*$param\">//p" | cut -d "<" -f1`
			val="$val"
			# truncate value if two long for col
			val=${val:0:char_per_col_list[$col_index]}
			printf '%s' "$col_del"
			printf "%-${char_per_col_list[$col_index]}s" "$val"
		done
		printf '\n'

	done

	printf '\n'
else
	# print specific line, create newline after each </param>, kill for each line all text until incl <param name=" pattern, replace "> with " = "
	sed -n '/PILATUS/p' ${filelist[0]} | sed 's/<\/param>/\n/g' | sed -n 's/^.*<param name="//p' | sed 's/">/ = /g'
fi
