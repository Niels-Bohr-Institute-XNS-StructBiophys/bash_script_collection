#!/bin/bash
# agr2pdf for selected / all *.agr files in a directory
# pdfcrop the *.pdf
# optionally rm ps and temporary pdf-files
# agr2pdfcropbatch
# agr2pdfcropbatch -r
# agr2pdfcropbatch -r *0[3-7]*cis.agr
# agr2pdfcropbatch *0[3-7]*cis.agr

# default
rmflag=false;
filelist=`ls *.agr`

echo $#
echo $@

# update with flags and arguments
if (( "$#" > 0 )); then
#	echo "$1"
	if [ "$1" == "-r" ]; then
		rmflag=true
		shift
	fi
	if (( "$#" > 0 )); then
		filelist=$@
	fi
fi

echo $filelist
#echo $rmflag

for inpf in ${filelist[@]}
do
	gracebat -printfile ${inpf/".agr"/".ps"} $inpf
	# gracebat -hdevice EPS -printfile ${inpf/".agr"/".ps"} $inpf
	# gracebat -hdevice PNG -printfile ${inpf/".agr"/".ps"} $inpf
	ps2pdf ${inpf/".agr"/".ps"} ${inpf/".agr"/".pdf"}
	pdfcrop ${inpf/".agr"/".pdf"} ${inpf/".agr"/"_cropped.pdf"}

	if $rmflag ; then
		rm  ${inpf/".agr"/".ps"} ${inpf/".agr"/".pdf"}
	fi
done
